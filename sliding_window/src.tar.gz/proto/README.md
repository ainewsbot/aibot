For more information about using protocol buffers from Python, see
https://developers.google.com/protocol-buffers/docs/pythontutorial
